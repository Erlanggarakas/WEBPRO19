# Jurnal Modul 5 Pemrograman WEB 2018/2019 IFLAB

Selamat Datang di Jurnal Modul 5 Pemrograman WEB 2018/2019 IFLAB,

Modul 5 ini terkait dengan penggunaan JSON dan AJAX pada pemrograman web.

Silakan Clone Repository ini untuk mulai mengerjakan jurnal
